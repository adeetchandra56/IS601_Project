# IS601_project/urls.py

from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('SAV_SHOP.urls')),
    path('SAV_SHOP', include('SAV_SHOP.urls')),
]