// Function to initialize cart items on page load
document.addEventListener('DOMContentLoaded', function() {
    // Fetch cart items from the server or use a global variable if available
    // Replace the following line with your actual API call or data source
    const cartItems = getCartItems(); // Assume getCartItems is a function that fetches cart items

    displayCartItems(cartItems);
});

// Function to display cart items
function displayCartItems(cartItems) {
    const cartTable = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');
    let total = 0;

    // Clear existing rows
    cartTable.innerHTML = '';

    // Populate cart table
    cartItems.forEach(function(item) {
        const newRow = cartTable.insertRow();

        const cell1 = newRow.insertCell(0);
        const cell2 = newRow.insertCell(1);
        const cell3 = newRow.insertCell(2);
        const cell4 = newRow.insertCell(3);

        cell1.textContent = item.itemName;
        cell2.textContent = '$' + item.price.toFixed(2);
        cell3.textContent = item.quantity;
        cell4.textContent = '$' + (item.price * item.quantity).toFixed(2);

        // Update total
        total += item.price * item.quantity;
    });

    // Update the total price
    totalPriceElement.textContent = '$' + total.toFixed(2);
}

// Example function to fetch cart items (replace with your actual implementation)
function getCartItems() {
    // This is where you would fetch cart items from your backend
    // For now, returning hardcoded mock data for testing
    return [
        { itemName: 'Pencil', price: 1.99, quantity: 2 },
        { itemName: 'Textbook', price: 10.99, quantity: 1 },
        // Add more items as needed
    ];
}
