# views.py

from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Product, Cart, Item
from django.http import JsonResponse

def get_items(request):
    items = Item.objects.all()
    items_data = [{'itemName': item.name, 'price': float(item.price)} for item in items]
    return JsonResponse(items_data, safe=False)

def get_items(request):
    items = Item.objects.all()
    items_data = [{'itemName': item.name, 'price': float(item.price)} for item in items]
    return JsonResponse(items_data, safe=False)


def index(request):
    return render(request, 'index.html')

def cart(request):
    # Retrieve cart data or items from the database or session
    cart_data = {
        'item1': {'name': 'Product 1', 'price': 20},
        'item2': {'name': 'Product 2', 'price': 30},
        # Add more items as needed
    }

    return render(request, 'cart.html', {'cart_data': cart_data})

def checkout(request):
    # Retrieve cart data from the request or session
    cart_data = request.GET.get('cart_data', '{}')
    # Convert the cart data from a string to a dictionary
    cart_data = eval(cart_data)

    # Perform additional logic or calculations as needed

    return render(request, 'checkout.html', {'cart_data': cart_data})


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return render(request, 'cart.html', {'product': product})